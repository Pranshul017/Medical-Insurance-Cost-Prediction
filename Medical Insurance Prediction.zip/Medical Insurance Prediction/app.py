import streamlit as st
import pandas as pd
import joblib

# Load trained model
model = joblib.load("best_insurance_model.joblib")

st.set_page_config(
    page_title="Medical Insurance Predictor",
    page_icon="🏥",
    layout="centered"
)

st.title("🏥 Medical Insurance Cost Prediction")

st.write(
    "Enter your details below to estimate medical insurance charges."
)

# User inputs
age = st.slider("Age", 18, 100, 25)

sex = st.selectbox(
    "Gender",
    ["male", "female"]
)

bmi = st.number_input(
    "BMI",
    min_value=10.0,
    max_value=60.0,
    value=25.0,
    step=0.1
)

children = st.number_input(
    "Number of Children",
    min_value=0,
    max_value=10,
    value=0,
    step=1
)

smoker = st.selectbox(
    "Smoking Status",
    ["no", "yes"]
)

region = st.selectbox(
    "Region",
    ["northeast", "northwest", "southeast", "southwest"]
)

if st.button("Predict Insurance Cost"):

    input_data = pd.DataFrame([{
        "age": age,
        "sex": sex,
        "bmi": bmi,
        "children": children,
        "smoker": smoker,
        "region": region
    }])

    prediction = model.predict(input_data)[0]

    st.success(
        f"Estimated Insurance Charges: ${prediction:,.2f}"
    )

    st.info(
        "This is an ML-based estimate, not an actual insurance quotation."
    )